module.exports = {
    props: ['user', 'team']
};
