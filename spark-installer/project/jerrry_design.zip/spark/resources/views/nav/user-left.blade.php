<!-- Left Side Of Navbar -->

<!--
<li class="nav-item">
    <a class="nav-link" href="#">Your Link</a>
</li>
-->