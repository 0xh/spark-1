<h6 class="dropdown-header">{{__('Support')}}</h6>

<!-- Support -->
<a class="dropdown-item" @click.prevent="showSupportForm" style="cursor: pointer;">
    <i class="fa fa-fw text-left fa-btn fa-paper-plane"></i> {{__('Email Us')}}
</a>

<div class="dropdown-divider"></div>
