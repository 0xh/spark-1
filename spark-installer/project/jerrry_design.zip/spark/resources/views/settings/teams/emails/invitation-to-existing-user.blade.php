{{__('Hi!')}}

<br><br>

{{__('teams.user_invited_to_join_team', ['userName' => $invitation->team->owner->name])}}

<br><br>

{{__('Since you already have an account, you may accept the invitation from your account settings screen.')}}

<br><br>

{{__('See you soon!')}}
