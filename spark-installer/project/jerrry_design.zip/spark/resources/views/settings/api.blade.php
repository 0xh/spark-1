<spark-api inline-template>
    <div>
        <!-- Create API Token -->
        <div>
            @include('spark::settings.api.create-token')
        </div>

        <!-- API Tokens -->
        <div>
            @include('spark::settings.api.tokens')
        </div>
    </div>
</spark-api>
