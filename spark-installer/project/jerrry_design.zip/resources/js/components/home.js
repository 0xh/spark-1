Vue.component('home', {
    props: ['user'],

    mounted() {
        //
    }
});
