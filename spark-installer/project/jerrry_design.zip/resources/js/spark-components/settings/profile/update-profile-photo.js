var base = require('settings/profile/update-profile-photo');

Vue.component('spark-update-profile-photo', {
    mixins: [base]
});
