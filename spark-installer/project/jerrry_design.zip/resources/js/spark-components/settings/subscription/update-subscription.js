var base = require('settings/subscription/update-subscription');

Vue.component('spark-update-subscription', {
    mixins: [base]
});
